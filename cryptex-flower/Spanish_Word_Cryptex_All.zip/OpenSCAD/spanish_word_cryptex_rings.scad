// Spanish Word Cryptex: customizable word rings
// Based on the p5.js sketch "Traceretry" (openprocessing.org/sketch/2609506)
// Fits the threaded base and end cap from the same project.
// License: CC BY-NC-SA 4.0
//
// Type one word (or short phrase) per face. Use "/" to split a face into two lines, e.g. "el/gato".
// Keep words to about 7 characters; longer words are shrunk to fit and print smaller.
// Ring 1 sits at the top of the stack, ring 4 at the bottom.

/* [Output] */
// Which part to generate
part = "all_rings"; // [all_rings:All four rings, ring_1:Ring 1 only, ring_2:Ring 2 only, ring_3:Ring 3 only, ring_4:Ring 4 only]

/* [Ring 1 (top): subject] */
r1_1 = "el/gato";
r1_2 = "el/sol";
r1_3 = "el/pollo";
r1_4 = "el/perro";
r1_5 = "la/luna";
r1_6 = "la/vaca";
r1_7 = "la/rana";
r1_8 = "la/casa";
r1_9 = "ella";
r1_10 = "él";

/* [Ring 2: when / how often] */
r2_1 = "siempre";
r2_2 = "nunca";
r2_3 = "no";
r2_4 = "también";
r2_5 = "ya";
r2_6 = "hoy";
r2_7 = "ahora";
r2_8 = "luego";
r2_9 = "pronto";
r2_10 = "casi";

/* [Ring 3: verb] */
r3_1 = "come";
r3_2 = "baila";
r3_3 = "canta";
r3_4 = "duerme";
r3_5 = "salta";
r3_6 = "corre";
r3_7 = "lee";
r3_8 = "nada";
r3_9 = "vuela";
r3_10 = "bebe";

/* [Ring 4 (bottom): how / where] */
r4_1 = "mucho";
r4_2 = "poco";
r4_3 = "bien";
r4_4 = "mal";
r4_5 = "aquí";
r4_6 = "allí";
r4_7 = "arriba";
r4_8 = "abajo";
r4_9 = "lejos";
r4_10 = "cerca";

/* [Text] */
// Font (any font installed; on MakerWorld most Google Fonts work)
font = "Liberation Sans:style=Bold";
// Largest letter size in mm
max_text_size = 5; // [3:0.5:6]
// How deep the words are cut into the face, in mm
text_depth = 1.0; // [0.4:0.2:1.6]
// Text width correction for the font (raise it if words run off the face, lower it if they look small)
width_scale = 1.4; // [1.0:0.05:2.0]

/* [Hidden] */
$fn = 96;
APO = 27;                          // flat-to-flat 54 mm (matches the base)
R = APO / cos(18);                 // decagon vertex radius
H = 9.6;                           // ring height
BORE = 36.8;                       // spindle is 36.0 mm
CH = 0.5;                          // bore chamfer
FACE_W = 2 * APO * tan(18);        // 17.54 mm
BOX_W = FACE_W - 1.6;
BOX_H = H - 1.6;
LINE_GAP = 1.25;

RINGS = [
  [r1_1, r1_2, r1_3, r1_4, r1_5, r1_6, r1_7, r1_8, r1_9, r1_10],
  [r2_1, r2_2, r2_3, r2_4, r2_5, r2_6, r2_7, r2_8, r2_9, r2_10],
  [r3_1, r3_2, r3_3, r3_4, r3_5, r3_6, r3_7, r3_8, r3_9, r3_10],
  [r4_1, r4_2, r4_3, r4_4, r4_5, r4_6, r4_7, r4_8, r4_9, r4_10]
];

// ---- string helpers (OpenSCAD 2021 compatible)
function join(v, i = 0) = i >= len(v) ? "" : str(v[i], join(v, i + 1));
function substr(s, a, b) = b <= a ? "" : join([for (i = [a : b - 1]) s[i]]);
function split_slash(s) =
  let (hits = search("/", s))
  len(hits) == 0 ? [s] : [substr(s, 0, hits[0]), substr(s, hits[0] + 1, len(s))];

// approximate letter widths (Liberation Sans Bold, in em) so words fit their face
function cw(c) =
  len(search(c, "ijlíìï'.,:;!| ")) > 0 ? 0.28 :
  len(search(c, "ftI")) > 0 ? 0.34 :
  c == "r" ? 0.39 :
  c == "m" ? 0.89 :
  c == "w" ? 0.78 :
  len(search(c, "MW")) > 0 ? 0.94 :
  len(search(c, "ABCDEFGHKNOPQRSTUVXYZÁÉÍÓÚÑ")) > 0 ? 0.72 :
  0.60;
function str_w(s, i = 0) = i >= len(s) ? 0 : cw(s[i]) + str_w(s, i + 1);

// ---- one face of text, laid out in the XY plane, centered
module face_text(word) {
  lines = split_slash(word);
  n = len(lines);
  widest = max([for (l = lines) str_w(l)]);
  size = min(max_text_size,
             BOX_W / (max(widest, 0.5) * width_scale),
             BOX_H / (n * LINE_GAP));
  intersection() {
    square([BOX_W, BOX_H], center = true);            // never spills onto the next face
    for (i = [0 : n - 1])
      translate([0, ((n - 1) / 2 - i) * size * LINE_GAP])
        text(lines[i], size = size, font = font, halign = "center", valign = "center", $fn = 16);
  }
}

module ring_blank() {
  difference() {
    cylinder(r = R, h = H, $fn = 10);                  // decagon, vertex on +X, a flat facing +Y
    translate([0, 0, -0.01]) cylinder(d = BORE, h = H + 0.02);
    translate([0, 0, -0.01]) cylinder(d1 = BORE + 2 * CH, d2 = BORE, h = CH);
    translate([0, 0, H - CH + 0.01]) cylinder(d1 = BORE, d2 = BORE + 2 * CH, h = CH);
  }
}

module word_ring(words) {
  difference() {
    ring_blank();
    for (k = [0 : 9])
      rotate([0, 0, 36 * k])                            // face k; face 1 faces +Y
        translate([0, APO, H / 2])
          rotate([90, 0, 180])                          // text reads left to right from outside
            translate([0, 0, -text_depth])
              linear_extrude(height = text_depth + 0.3)
                face_text(words[k]);
  }
}

// ---- layout
if (part == "all_rings") {
  for (i = [0 : 3])
    translate([(i % 2) * 64 - 32, (i < 2 ? 1 : -1) * 32, 0]) word_ring(RINGS[i]);
} else {
  idx = part == "ring_1" ? 0 : part == "ring_2" ? 1 : part == "ring_3" ? 2 : 3;
  word_ring(RINGS[idx]);
}
