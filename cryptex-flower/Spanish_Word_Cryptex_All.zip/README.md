# Spanish Word Cryptex (Traceretry)

A spinning word cryptex that builds beginner-level Spanish sentences. Four rings with ten words each give 10,000 grammatical (and often whimsical) sentences. Spin the rings and read the sentence in a column, top to bottom.

It is a physical version of the p5.js sketch "Traceretry": https://openprocessing.org/sketch/2609506

Designed by [Your name]. License: CC BY-NC-SA 4.0 (see "Credits and license" below).

---

## Which files do I need?

| I want to... | Use these files |
|---|---|
| Print it as is, on any printer | Everything in `STL/` |
| Print it as is, on a Bambu Lab printer | Both files in `Bambu_Studio/` |
| Change the words | `OpenSCAD/spanish_word_cryptex_rings.scad`, plus `STL/01` and `STL/02` for the base and cap |

---

## Every file, explained

### STL/ (works with every slicer)
STL is the universal 3D printing format. It opens in Bambu Studio, OrcaSlicer, PrusaSlicer, Cura, and others. Each part is already positioned the right way up for printing.

| File | What it is | Size (mm) |
|---|---|---|
| `01_base_threaded.stl` | The base: a 10-sided foot with a spindle the rings slide onto. The top of the spindle is threaded. A small raised marker on one side shows where to read the sentence. | 57 x 55 x 52 |
| `02_end_cap_threaded.stl` | The cap that screws onto the top of the spindle and holds the rings on. It prints upside down, with the thread facing up. | 57 x 55 x 8 |
| `03_word_ring_1.stl` | Ring 1 (top): subjects, such as "el gato" | 57 x 54 x 9.6 |
| `04_word_ring_2.stl` | Ring 2: when or how often, such as "siempre" | 57 x 54 x 9.6 |
| `05_word_ring_3.stl` | Ring 3: verbs, such as "baila" | 57 x 54 x 9.6 |
| `06_word_ring_4.stl` | Ring 4 (bottom): how or where, such as "arriba" | 57 x 54 x 9.6 |

### Bambu_Studio/ (for Bambu Lab printers)
Ready-made plates for Bambu Studio. When you open one, Studio may say the file "has invalid config" and will load geometry only. That is normal: click OK, then choose your printer, plate, and PLA filament.

| File | What it is |
|---|---|
| `casing_base_and_cap.3mf` | The base and cap together on one plate |
| `word_rings.3mf` | All four word rings together on one plate |

### OpenSCAD/ (to change the words)
| File | What it is |
|---|---|
| `spanish_word_cryptex_rings.scad` | An editable script that builds the four word rings. It holds 40 text fields, one per face, grouped by ring. It does not include the base and cap, which never change, so print those from `STL/`. |

### Images/
| File | What it is |
|---|---|
| `word_faces_preview.png` | All 40 ring faces as they read from outside, for checking the words before printing |

---

## Print settings

- Material: PLA, one color (no filament changes needed)
- Nozzle: 0.4 mm
- Layer height: 0.2 mm (0.16 mm gives crisper small words)
- Infill: 15%
- Supports: none
- Filament: about 55 g for everything
- Time: about 2 to 2.5 hours total on a Bambu Lab A1 (two plates)

The words are recessed 1 mm into each face. To make them stand out, rub acrylic paint or a paint marker into the recesses, then wipe the surface clean.

---

## Assembly

1. Stand the base on its flat bottom.
2. Slide the rings onto the spindle in this order: ring 4, ring 3, ring 2, ring 1. Keep the words upright.
3. Screw the cap onto the threaded top until it stops.
4. Spin the rings. Read the sentence top to bottom in the column above the small raised marker on the base.

**If the rings spin stiffly,** the ring holes printed a little small. Reprint the rings scaled up 1% in the X and Y directions only.
**If the cap is hard to screw on,** check the thread for stray strings of plastic and trim them.

---

## Changing the words

### In OpenSCAD (free: https://openscad.org)
1. Open `spanish_word_cryptex_rings.scad`.
2. Open the customizer: Window > Customizer.
3. Type your words into the fields. Use "/" to put a face on two lines, for example `el/gato`.
4. Under "Output," choose all rings or a single ring.
5. Press F6 to render, then File > Export > Export as STL.

### On MakerWorld
Upload the `.scad` file as part of a listing, and MakerWorld adds a "Customize" button so anyone can edit the words in a web browser.

### Tips
- Keep words to about 7 characters. Longer words shrink to fit and print smaller.
- Words never spill onto the next face; anything too wide is shrunk, then clipped at the face edge.
- To keep every sentence grammatical, keep each ring to one grammatical job and avoid words that change for gender on rings 2 to 4.
- Other settings: font, maximum letter size, recess depth, and a width correction for fonts that run wide or narrow.

---

## The words

| Ring 1: subject | Ring 2: when / how often | Ring 3: verb | Ring 4: how / where |
|---|---|---|---|
| el gato (the cat) | siempre (always) | come (eats) | mucho (a lot) |
| el sol (the sun) | nunca (never) | baila (dances) | poco (a little) |
| el pollo (the chicken) | no (does not) | canta (sings) | bien (well) |
| el perro (the dog) | también (also) | duerme (sleeps) | mal (badly) |
| la luna (the moon) | ya (already) | salta (jumps) | aquí (here) |
| la vaca (the cow) | hoy (today) | corre (runs) | allí (there) |
| la rana (the frog) | ahora (now) | lee (reads) | arriba (up, above) |
| la casa (the house) | luego (later) | nada (swims) | abajo (down, below) |
| ella (she) | pronto (soon) | vuela (flies) | lejos (far away) |
| él (he) | casi (almost) | bebe (drinks) | cerca (nearby) |

Every combination is grammatical: all subjects are third person singular, and no word on rings 2 to 4 changes for gender.

Example: *La vaca siempre vuela arriba.* (The cow always flies up.)

---

## Credits and license

- Concept and word grammar: [Your name], from the p5.js sketch "Traceretry" (CC BY-NC-SA).
- Base footprint: adapted from "Number Safe - Cryptex" by finniminni (CC BY-NC), https://makerworld.com/en/models/882024, measured from the remix "Cryptex Zelda Symbol" by L.TS (CC BY-NC-SA), https://makerworld.com/en/models/970985.
- Word rings, threaded spindle, and screw-on cap: new designs.

This project is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0): https://creativecommons.org/licenses/by-nc-sa/4.0/. You may share and remix it for noncommercial purposes if you credit the creators and share your version under the same license.
